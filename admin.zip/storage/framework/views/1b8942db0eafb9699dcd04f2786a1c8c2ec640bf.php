<?php $__env->startSection('title', 'Products Page'); ?>

<?php $__env->startSection('content'); ?>


    <!-- Begin page content -->
    <main class="flex-shrink-0">
        <div class="container">
            <h1 class="mt-5">Slider Images</h1>

            <?php $__currentLoopData = $slider; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $s): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <img src="<?php echo e(url('/')); ?>/public/uploads/<?php echo e($s->image); ?>" style="height: 120px; margin-top: 60px" alt="">
                <form action="<?php echo e(route('admin.slider.update')); ?>" method="post" enctype="multipart/form-data">
                    <?php echo csrf_field(); ?>
                    <input type="hidden" name="id" value="<?php echo e($s->id); ?>">
                    <input type="file" name="image" style="margin-top: 10px" accept="image/*" required>
                    <button class="btn btn-dark" type="submit">Change</button>
                </form>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </main>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('dashboard.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\alltech\dynamic\resources\views/dashboard/pages/slider.blade.php ENDPATH**/ ?>