<?php $__env->startSection('title', 'About Us Page'); ?>

<?php $__env->startSection('content'); ?>


    <!-- Begin page content -->
    <main class="flex-shrink-0">
        <div class="container">
            <h1 class="mt-5">About Us</h1>

            <table id="example" class="table table-striped table-bordered" style="width:100%">
                <thead>
                <tr>
                    <th>Name</th>
                    <th>Name (AR)</th>
                    <th>Action</th>
                </tr>
                </thead>
                <tbody>
                    <tr>
                        <td><?php echo e($about->text); ?></td>
                        <td><?php echo e($about->text_ar); ?></td>
                        <td>
                            <button class="btn btn-lg btn-primary" type="button" onclick="location.href='<?php echo e(route('about-us.edit', $about->id)); ?>'">Edit</button>
                        </td>
                    </tr>
                </tbody>
                <tfoot>
                    <th>Name</th>
                    <th>Name (AR)</th>
                    <th>Action</th>
                </tr>
                </tfoot>
            </table>
        </div>
    </main>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('dashboard.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\alltech\dynamic\resources\views/dashboard/pages/about-us/index.blade.php ENDPATH**/ ?>