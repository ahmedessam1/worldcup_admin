<footer class="footer mt-auto py-3 bg-light">
    <div class="container">
        <span class="text-muted">© Copyright <?php echo e(date("Y")); ?></span>
    </div>
</footer>
<?php /**PATH G:\xampp\htdocs\worldcup\admin\resources\views/dashboard/partials/_footer.blade.php ENDPATH**/ ?>