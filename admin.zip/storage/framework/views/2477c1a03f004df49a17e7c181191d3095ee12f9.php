<?php $__env->startSection('title', 'News Page'); ?>

<?php $__env->startSection('content'); ?>


    <!-- Begin page content -->
    <main class="flex-shrink-0">
        <div class="container">
            <h1 class="mt-5">Transportation</h1>
            <a class="btn btn-lg btn-primary mb-3" href="<?php echo e(route('transportations.create')); ?>">Add Player Transportation</a>
            <table id="example" class="table table-striped table-bordered" style="width:100%">
                <thead>
                <tr>
                    <th>Player</th>
                    <th>From Location</th>
                    <th>To Location</th>
                    <th>Time</th>
                    <th>Date</th>
                    <th>Action</th>
                </tr>
                </thead>
                <tbody>
                <?php $__empty_1 = true; $__currentLoopData = $model; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $m): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <tr>
                        <td><?php echo e($m->player->name); ?> - <?php echo e($m->player->email); ?></td>
                        <td><?php echo e($m->from_location); ?> - <small style="font-weight: bold; color: #0d6efd"><?php echo e($m->from_description); ?></small></td>
                        <td><?php echo e($m->to_location); ?> - <small style="font-weight: bold; color: #0d6efd"><?php echo e($m->to_description); ?></small></td>
                        <td><?php echo e($m->from_time); ?>-><?php echo e($m->to_time); ?></td>
                        <td><?php echo e($m->date); ?></td>
                        <td>
                            <a href="<?php echo e(route('transportations.edit', $m->id)); ?>" class="btn btn-primary"><i class="fa fa-edit"></i>Edit</a>
                            <form style="display: inline" method="post"
                                  action="<?php echo e(route('transportations.destroy',[$m->id])); ?>">
                                <?php echo csrf_field(); ?>
                                <?php echo method_field('DELETE'); ?>
                                <button class="btn btn-danger" type="submit"><i class="fa fa-trash"></i>Delete</button>
                            </form>
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <tr>
                        <td colspan="5"> There is no rows</td>
                    </tr>
                <?php endif; ?>
                </tbody>
            </table>
        </div>
    </main>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('dashboard.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH G:\xampp\htdocs\worldcup\admin\resources\views/dashboard/pages/transportations/index.blade.php ENDPATH**/ ?>