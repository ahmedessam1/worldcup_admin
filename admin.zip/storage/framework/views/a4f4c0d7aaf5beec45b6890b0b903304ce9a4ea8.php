<?php $__env->startSection('title', 'New Product Page'); ?>

<?php $__env->startSection('content'); ?>

    <!-- Begin page content -->
    <main class="flex-shrink-0">
        <div class="container">
            <h1 class="mt-5">Edit Player Info</h1>
            <main>
                <div class="row g-5">
                    <form action="<?php echo e(route('players.update', $player->id)); ?>" method="post">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('put'); ?>
                        <div class="row">
                            <div class="col-md-6">
                                <label for="name" class="form-label">Name</label>
                                <input type="text" class="form-control" value="<?php echo e($player->name); ?>" id="name" name="name" placeholder="Enter the player name" value="" required>
                            </div>

                            <div class="col-md-6">
                                <label for="email" class="form-label">Email</label>
                                <input type="email" class="form-control" value="<?php echo e($player->email); ?>" id="email" name="email" placeholder="Enter the player official Email" value="" required>
                            </div>
                        </div>

                        <div class="row" style="margin-top: 20px">
                            <div class="col-md-6">
                                <label for="country" class="form-label">Country</label>
                                <select name="country" id="country" class="form-control" required>
                                    <option value="">-SELECT PLAYER COUNTRY-</option>
                                    <?php $__currentLoopData = $countries; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $country): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($country->name); ?>"
                                        <?php if($player->country === $country->name): ?>
                                            selected
                                        <?php endif; ?>
                                        ><?php echo e($country->name); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                            </div>

                            <div class="col-md-6">
                                <label for="gender" class="form-label">Gender</label>
                                <select name="gender" id="gender" class="form-control" required>
                                    <option value="">-SELECT PLAYER GENDER-</option>
                                    <option value="Male"
                                    <?php if($player->gender === 'Male'): ?>
                                        selected
                                    <?php endif; ?>>Male</option>
                                    <option value="Female"
                                    <?php if($player->gender === 'Female'): ?>
                                        selected
                                    <?php endif; ?>>Female</option>
                                </select>
                            </div>
                        </div>

                        <div class="row" style="margin-top: 20px">
                            <div class="col-md-6">
                                <label for="age" class="form-label">Age</label>
                                <input type="number" class="form-control" value="<?php echo e($player->age); ?>" id="age" name="age" placeholder="Enter the player age" value="" required>
                            </div>

                            <div class="col-md-6">
                                <label for="facebook" class="form-label">Facebook</label>
                                <input type="text" class="form-control" value="<?php echo e($player->facebook); ?>" id="facebook" name="facebook" placeholder="Enter the player Facebook link" value="" required>
                            </div>
                        </div>

                        <div class="row" style="margin-top: 20px">
                            <div class="col-md-6">
                                <label for="instagram" class="form-label">Instagram</label>
                                <input type="text" class="form-control" value="<?php echo e($player->instagram); ?>" id="instagram" name="instagram" placeholder="Enter the player Instagram link" value="" required>
                            </div>

                            <div class="col-md-6">
                                <label for="twitter" class="form-label">Twitter</label>
                                <input type="text" class="form-control" value="<?php echo e($player->twitter); ?>" id="twitter" name="twitter" placeholder="Enter the player Twitter link" value="" required>
                            </div>
                        </div>

                        <div class="row" style="margin-top: 20px">
                            <div class="col-md-6">
                                <label for="password" class="form-label">Password <small style="color: blue">(Enter password only if you want to change it)</small></label>
                                <input type="password" class="form-control" id="password" name="password" placeholder="Enter the player login password" value="">
                            </div>
                        </div>

                        <button class="w-100 btn btn-primary btn-lg" style="margin-top: 30px" type="submit"><i class="fa fa-edit"></i> Edit Player</button>
                    </form>
                </div>
            </main>
        </div>
    </main>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('dashboard.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH G:\xampp\htdocs\worldcup\admin\resources\views/dashboard/pages/players/edit.blade.php ENDPATH**/ ?>