<footer class="footer mt-auto py-3 bg-light">
    <div class="container">
        <span class="text-muted">© Copyright <?php echo e(date("Y")); ?></span>
    </div>
</footer>
<?php /**PATH C:\xampp\htdocs\alltech\dynamic\resources\views/dashboard/partials/_footer.blade.php ENDPATH**/ ?>