<?php $__env->startSection('title', 'Alltech News'); ?>

<?php $__env->startSection('content'); ?>
    <div class="page-content bg-white">
        <!-- inner page banner -->
        <div class="dlab-bnr-inr overlay-black-middle text-center bg-pt"
             style="background-image:url(<?php echo e(url('/')); ?>/public/images/background/bg2.jpg);">
            <div class="container">
                <div class="dlab-bnr-inr-entry align-m text-center">
                    <h1 class="text-white"><?php echo app('translator')->get('lang.news.1'); ?></h1>
                    <!-- Breadcrumb row -->
                    <div class="breadcrumb-row">
                        <ul class="list-inline">
                            <li><a href="<?php echo e(route('pages.home')); ?>"><?php echo app('translator')->get('lang.news.2'); ?></a></li>
                            <li><?php echo app('translator')->get('lang.news.3'); ?></li>

                            <?php if(Session::get('locale') === 'en'): ?>
                                <li><?php echo e($category->name); ?></li>
                            <?php else: ?>
                                <li><?php echo e($category->name_ar); ?></li>
                            <?php endif; ?>
                        </ul>
                    </div>
                    <!-- Breadcrumb row END -->
                </div>
            </div>
        </div>
        <!-- inner page banner END -->
        <!-- contact area -->
        <div class="content-block">
            <!-- About Services info -->
            <div class="section-full content-inner bg-white video-section"
                 style="background-image:url(<?php echo e(url('/')); ?>/public/images/background/bg-video.png);">
                <div class="container">

                    <div class="row">
                        <?php $__currentLoopData = $news; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $n): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="col-md-4">
                                <div class="blog-post post-style-1">
                                    <div class="dlab-post-media dlab-img-effect rotate">
                                        <a href="<?php echo e(route('pages.news.show', $n->id)); ?>"><img class="news--image" src="<?php echo e(url('/')); ?>/public/uploads/<?php echo e($n->image); ?>" alt=""></a>
                                    </div>
                                    <div class="dlab-post-info">
                                        <div class="dlab-post-meta">
                                            <ul>
                                                <li class="post-date"> <strong><?php echo e($n->created_at->diffForHumans()); ?></strong> </li>
                                                <?php if(Session::get('locale') === 'en'): ?>
                                                    <li class="post-author"> <?php echo e($n->category->name); ?> </li>
                                                <?php else: ?>
                                                    <li class="post-author"> <?php echo e($n->category->name_ar); ?> </li>
                                                <?php endif; ?>
                                            </ul>
                                        </div>
                                        <div class="dlab-post-title">
                                            <?php if(Session::get('locale') === 'en'): ?>
                                                <h3 class="post-title"><a href="<?php echo e(route('pages.news.show', $n->id)); ?>"><?php echo e($n->name); ?></a></h3>
                                            <?php else: ?>
                                                <h3 class="post-title"><a href="<?php echo e(route('pages.news.show', $n->id)); ?>"><?php echo e($n->name_ar); ?></a></h3>
                                            <?php endif; ?>
                                        </div>
                                        <div class="dlab-post-readmore">
                                            <a href="<?php echo e(route('pages.news.show', $n->id)); ?>" title="READ MORE" rel="bookmark" class="site-button btnhover13"><?php echo app('translator')->get('lang.news.4'); ?></a>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>

                </div>
            </div>
        </div>
        <!-- contact area END -->
    </div>


    <div class="modal fade" id="model" tabindex="-1" role="dialog">
        <div class="modal-dialog" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span
                            aria-hidden="true">&times;</span></button>
                    <h4 class="modal-title"></h4>
                </div>
                <div class="modal-body">
                    <img src="" class="modal-image" alt="">
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
                </div>
            </div><!-- /.modal-content -->
        </div><!-- /.modal-dialog -->
    </div><!-- /.modal -->
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
    <script>
        $('.modal').on('shown.bs.modal', function () {
            let image = $(this).data('src');
            let title = $(this).data('title');

            $('.modal-image').attr('src', image);
            $('.modal-title').text(title);
        });
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\alltech\dynamic\resources\views/pages/news.blade.php ENDPATH**/ ?>