<?php $__env->startSection('title', 'Players Page'); ?>

<?php $__env->startSection('content'); ?>


    <!-- Begin page content -->
    <main class="flex-shrink-0">
        <div class="container">
            <h1 class="mt-5">Plays</h1>
            <a class="btn btn-lg btn-primary mb-3" href="<?php echo e(route('players.create')); ?>">Add New Player</a>
            <table id="example" class="table table-striped table-bordered" style="width:100%">
                <thead>
                <tr>
                    <th class="text-center">Name</th>
                    <th class="text-center">Email</th>
                    <th class="text-center">Gender</th>
                    <th class="text-center">Age</th>
                    <th class="text-center">Country</th>
                    <th class="text-center">Social Media</th>
                    <th class="text-center"><i class="fa fa-cog"></i></th>
                </tr>
                </thead>
                <tbody>
                <?php $__empty_1 = true; $__currentLoopData = $model; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $m): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <tr>
                        <td class="text-center"><?php echo e($m->name); ?></td>
                        <td class="text-center"><a href="mailto:<?php echo e($m->email); ?>"><?php echo e($m->email); ?></a></td>
                        <td class="text-center"><?php echo e($m->gender); ?></td>
                        <td class="text-center"><?php echo e($m->age); ?></td>
                        <td class="text-center"><?php echo e($m->country); ?></td>
                        <td class="text-center">
                            <a href="<?php echo e($m->facebook); ?>" class="social-icon" target="_blank"><i class="fa fa-facebook"></i></a>
                            <a href="<?php echo e($m->twitter); ?>" class="social-icon" target="_blank"><i class="fa fa-twitter"></i></a>
                            <a href="<?php echo e($m->instagram); ?>" class="social-icon" target="_blank"><i class="fa fa-instagram"></i></a>
                        </td>
                        <td class="text-center">
                            <button class="btn btn-lg btn-primary" type="button" onclick="location.href='<?php echo e(route('players.edit', $m->id)); ?>'">Edit</button>

                            <form style="display: inline" method="post"
                                  action="<?php echo e(route('players.destroy',[$m->id])); ?>">
                                <?php echo csrf_field(); ?>
                                <?php echo method_field('DELETE'); ?>
                                <button class="btn btn-lg btn-danger" type="submit">Delete</button>
                            </form>
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <tr>
                        <td colspan="5"> There is no rows</td>
                    </tr>
                <?php endif; ?>
                </tbody>
            </table>
        </div>
    </main>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('dashboard.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH G:\xampp\htdocs\worldcup\admin\resources\views/dashboard/pages/players/index.blade.php ENDPATH**/ ?>