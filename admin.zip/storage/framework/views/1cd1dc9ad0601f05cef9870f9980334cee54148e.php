<?php $__env->startSection('title', 'New News Page'); ?>

<?php $__env->startSection('content'); ?>


    <!-- Begin page content -->
    <main class="flex-shrink-0">
        <div class="container">
            <h1 class="mt-5">New Video</h1>
            <main>
                <div class="row g-5">
                    <div class="col-12">
                        <form action="<?php echo e(route('videos.store')); ?>" method="post" enctype="multipart/form-data">
                            <?php echo csrf_field(); ?>
                            <div class="col-sm-12">
                                <label for="title" class="form-label">Title</label>
                                <input type="text" class="form-control" id="title" name="title" placeholder="Enter the title" value="" required>
                            </div>


                            <div class="col-sm-12">
                                <label for="link" class="form-label">Video Link</label>
                                <input type="text" class="form-control" id="link" name="link" placeholder="Enter the link" value="" required>
                            </div>

                            <button class="w-100 btn btn-primary btn-lg" type="submit">Add</button>
                        </form>
                    </div>
                </div>
            </main>
        </div>
    </main>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('dashboard.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH G:\xampp\htdocs\worldcup\admin\resources\views/dashboard/pages/videos/create.blade.php ENDPATH**/ ?>