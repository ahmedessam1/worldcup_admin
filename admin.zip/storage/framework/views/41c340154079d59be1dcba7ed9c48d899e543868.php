<?php $__env->startSection('title', 'New News Page'); ?>

<?php $__env->startSection('content'); ?>


    <!-- Begin page content -->
    <main class="flex-shrink-0">
        <div class="container">
            <h1 class="mt-5">New News</h1>
            <main>
                <div class="row g-5">
                    <div class="col-12">
                        <form action="<?php echo e(route('news.store')); ?>" method="post" enctype="multipart/form-data">
                            <?php echo csrf_field(); ?>
                            <div class="col-sm-12">
                                <label for="name" class="form-label">Name</label>
                                <input type="text" class="form-control" id="name" name="name" placeholder="" value="" required>
                            </div>
                            <div class="col-sm-12">
                                <label for="name_ar" class="form-label">Name (AR)</label>
                                <input type="text" class="form-control" id="name_ar" name="name_ar" placeholder="" value="" required>
                            </div>

                            <div class="col-sm-12">
                                <label for="description" class="form-label">Description</label>
                                <textarea type="text" class="form-control" id="editor" name="description" placeholder=""></textarea>
                            </div>
                            <div class="col-sm-12">
                                <label for="description_ar" class="form-label">Description (AR)</label>
                                <textarea type="text" class="form-control editor" id="description_ar" name="description_ar" placeholder="" required></textarea>
                            </div>

                            <div class="col-sm-12">
                                <label for="category" class="form-label">Category</label>
                                <select class="form-control" id="category_id" name="category_id" required>
                                    <option value=""> Choose Category</option>
                                    <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($category->id); ?>"><?php echo e($category->name); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                            </div>

                            <div class="col-sm-12 mb-5">
                                <label for="image" class="form-label">Image</label>
                                <input type="file" class="form-control" id="image" name="image" required>
                            </div>

                            <button class="w-100 btn btn-primary btn-lg" type="submit">Create</button>
                        </form>
                    </div>
                </div>
            </main>
        </div>
    </main>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('dashboard.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\alltech\dynamic\resources\views/dashboard/pages/news/create.blade.php ENDPATH**/ ?>