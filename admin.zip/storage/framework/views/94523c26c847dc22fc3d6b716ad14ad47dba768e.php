<!doctype html>
    <html lang="en" class="h-100">

    <?php echo $__env->make('dashboard.partials._head', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <body class="d-flex flex-column h-100">

    <?php echo $__env->make('dashboard.partials._header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <div class="container">
        <?php echo $__env->make('dashboard.partials._messages', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    </div>
    <?php echo $__env->yieldContent('content'); ?>


    <?php echo $__env->make('dashboard.partials._footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <?php echo $__env->make('dashboard.partials._scripts', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <?php echo $__env->yieldContent('scripts'); ?>
    </body>
</html>
<?php /**PATH G:\xampp\htdocs\worldcup\admin\resources\views/dashboard/main.blade.php ENDPATH**/ ?>