
<?php $__env->startSection('title', 'Categories Page'); ?>

<?php $__env->startSection('content'); ?>


    <!-- Begin page content -->
    <main class="flex-shrink-0">
        <div class="container">
            <h1 class="mt-5">Categories</h1>
            <a class="btn btn-lg btn-primary mb-3" href="<?php echo e(route('categories.create')); ?>">New Category</a>
            <table id="example" class="table table-striped table-bordered" style="width:100%">
                <thead>
                <tr>
                    <th>Name</th>
                    <th>Name (AR)</th>
                    <th>Action</th>
                </tr>
                </thead>
                <tbody>
                <?php $__empty_1 = true; $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <tr>
                        <td><?php echo e($category->name); ?></td>
                        <td><?php echo e($category->name_ar); ?></td>
                        <td>
                            <button class="btn btn-lg btn-primary" type="button" onclick="location.href='<?php echo e(route('categories.edit', $category->id)); ?>'">Edit</button>
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <tr>
                        <td colspan="2"> There is no rows</td>
                    </tr>
                <?php endif; ?>
                </tbody>
                <tfoot>
                    <th>Name</th>
                    <th>Name (AR)</th>
                    <th>Action</th>
                </tr>
                </tfoot>
            </table>
        </div>
    </main>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('dashboard.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\alltech\dynamic\resources\views/dashboard/pages/categories/index.blade.php ENDPATH**/ ?>