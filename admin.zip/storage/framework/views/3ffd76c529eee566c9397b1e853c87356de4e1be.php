<?php $__env->startSection('title', 'News Page'); ?>

<?php $__env->startSection('content'); ?>


    <!-- Begin page content -->
    <main class="flex-shrink-0">
        <div class="container">
            <h1 class="mt-5">News</h1>
            <a class="btn btn-lg btn-primary mb-3" href="<?php echo e(route('news.create')); ?>">New News</a>
            <table id="example" class="table table-striped table-bordered" style="width:100%">
                <thead>
                <tr>
                    <th>Image</th>
                    <th>Name</th>
                    <th>Name (AR)</th>
                    <th>Category</th>
                    <th>Description</th>
                    <th>Description (AR)</th>
                    <th>Action</th>
                </tr>
                </thead>
                <tbody>
                <?php $__empty_1 = true; $__currentLoopData = $news; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $news): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <tr>
                        <td><img style="width: 60px; height: 60px" src="<?php echo e(asset('public/uploads/'.$news->image)); ?>" alt="<?php echo e($news->name); ?>"></td>
                        <td><?php echo e($news->name); ?></td>
                        <td><?php echo e($news->name_ar); ?></td>
                        <td><?php echo e($news->category->name); ?></td>
                        <td><?php echo e($news->description); ?></td>
                        <td><?php echo e($news->description_ar); ?></td>
                        <td>
                            <button class="btn btn-lg btn-primary" type="button" onclick="location.href='<?php echo e(route('news.edit', $news->id)); ?>'">Edit</button>
                            <button class="btn btn-lg btn-success" type="button" onclick="window.open('<?php echo e(route('pages.news.show', $news->id)); ?>')">Show</button>

                            <form style="display: inline" method="post"
                                  action="<?php echo e(route('news.destroy',[$news->id])); ?>">
                                <?php echo csrf_field(); ?>
                                <?php echo method_field('DELETE'); ?>
                                <button class="btn btn-lg btn-danger" type="submit">Delete</button>
                            </form>
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <tr>
                        <td colspan="5"> There is no rows</td>
                    </tr>
                <?php endif; ?>
                </tbody>
                <tfoot>
                <tr>
                    <th>Image</th>
                    <th>Name</th>
                    <th>Name (AR)</th>
                    <th>Category</th>
                    <th>Description</th>
                    <th>Description (AR)</th>
                    <th>Action</th>
                </tr>
                </tfoot>
            </table>
        </div>
    </main>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('dashboard.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\alltech\dynamic\resources\views/dashboard/pages/news/index.blade.php ENDPATH**/ ?>