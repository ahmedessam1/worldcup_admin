<style>
    .nav-item a {
        font-size: 16px;
        color: #fff !important;
    }
    .nav-item {
        border-right: 1px solid #ddd
    }
    .navbar-dark .navbar-nav .nav-link.active, .navbar-dark .navbar-nav .show>.nav-link {
        background-color: #6c757d;
    }
</style>
<header>
    <!-- Fixed navbar -->
    <nav class="navbar navbar-expand-md navbar-dark fixed-top bg-dark">
        <div class="container">
            <a class="navbar-brand" href="#"><img src="<?php echo e(url('/')); ?>/public/images/logo.jpg" alt="" style="height: 40px"></a>
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarCollapse" aria-controls="navbarCollapse" aria-expanded="false" aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarCollapse">
                <ul class="navbar-nav ms-auto">
                    <li class="nav-item">
                        <a class="nav-link <?php echo e(request()->routeIs('products.*') ? 'active' : null); ?>" aria-current="page" href="<?php echo e(route('products.index')); ?>">Products</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link <?php echo e(request()->routeIs('categories.*') ? 'active' : null); ?>" aria-current="page" href="<?php echo e(route('categories.index')); ?>">Product Categories</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link <?php echo e(request()->routeIs('news.*') ? 'active' : null); ?>" aria-current="page" href="<?php echo e(route('news.index')); ?>">News</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link <?php echo e(request()->routeIs('news-categories.*') ? 'active' : null); ?>" aria-current="page" href="<?php echo e(route('news-categories.index')); ?>">News Categories</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link <?php echo e(request()->routeIs('admin.slider.*') ? 'active' : null); ?>" aria-current="page" href="<?php echo e(route('admin.slider.index')); ?>">Slider</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link <?php echo e(request()->routeIs('about-us.*') ? 'active' : null); ?>" aria-current="page" href="<?php echo e(route('about-us.index')); ?>">About Us</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" aria-current="page" href="<?php echo e(route('pages.home')); ?>" target="_blank">Website</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" aria-current="page" href="#" onclick="document.getElementById('logout_form').submit()">Logout</a>
                        <form action="<?php echo e(route('logout')); ?>" method="POST" id="logout_form"><?php echo csrf_field(); ?></form>
                    </li>
                </ul>
            </div>
        </div>
    </nav>
</header>
<?php /**PATH C:\xampp\htdocs\alltech\dynamic\resources\views/dashboard/partials/_header.blade.php ENDPATH**/ ?>