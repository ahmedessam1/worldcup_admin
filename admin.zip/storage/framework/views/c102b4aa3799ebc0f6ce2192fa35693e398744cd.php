<!-- JAVASCRIPT FILES ========================================= -->
<script src="<?php echo e(url('/')); ?>/public/js/combining.js"></script><!-- CONTACT JS  -->
<script src="<?php echo e(url('/')); ?>/public/js/jquery.lazy.min.js"></script>
<!-- REVOLUTION JS FILES -->
<script src="<?php echo e(url('/')); ?>/public/plugins/revolution/revolution/js/jquery.themepunch.tools.min.js"></script>
<script src="<?php echo e(url('/')); ?>/public/plugins/revolution/revolution/js/jquery.themepunch.revolution.min.js"></script>
<script src="<?php echo e(url('/')); ?>/public/js/rev.slider.js"></script>
<script>
    jQuery(document).ready(function() {
        'use strict';
        dz_rev_slider_2();
        $('.lazy').Lazy();
    });	/*ready*/
</script>

<script>
$('.locale').click(function() {
    let locale = $(this).data('locale');
    $('#locale').val(locale);
    $('#locale_form').submit();
});
</script>
<?php /**PATH G:\xampp\htdocs\worldcup\admin\resources\views/partials/_scripts.blade.php ENDPATH**/ ?>