<?php $__env->startSection('title', 'Edit About Us Page'); ?>

<?php $__env->startSection('content'); ?>


    <!-- Begin page content -->
    <main class="flex-shrink-0">
        <div class="container">
            <h1 class="mt-5">Edit About Us</h1>
            <main>
                <div class="row g-5">
                    <div class="col-12">
                        <form action="<?php echo e(route('about-us.update', $about->id)); ?>" method="post" enctype="multipart/form-data">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('put'); ?>
                            <div class="col-sm-12">
                                <label for="text" class="form-label">About Us</label>
                                <textarea type="text" class="form-control" id="editor" name="text" placeholder="" required><?php echo e($about->text); ?></textarea>
                            </div>
                            <div class="col-sm-12 mb-5">
                                <label for="text_ar" class="form-label">About Us (AR)</label>
                                <textarea type="text" class="form-control editor" name="text_ar" placeholder="" required><?php echo e($about->text_ar); ?></textarea>
                            </div>
                            <button class="w-100 btn btn-primary btn-lg" type="submit">Update</button>
                        </form>
                    </div>
                </div>
            </main>
        </div>
    </main>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('dashboard.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\alltech\dynamic\resources\views/dashboard/pages/about-us/edit.blade.php ENDPATH**/ ?>