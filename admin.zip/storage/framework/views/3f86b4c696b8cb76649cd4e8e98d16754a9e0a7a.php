<?php $__env->startSection('title'); ?>
    <?php echo e($product->name); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="page-content bg-white">
        <!-- inner page banner -->
        <div class="dlab-bnr-inr overlay-black-middle text-center bg-pt"
             style="background-image:url(<?php echo e(url('/')); ?>/public/images/background/bg2.jpg);">
            <div class="container">
                <div class="dlab-bnr-inr-entry align-m text-center">
                    <h1 class="text-white"><?php echo e($product->name); ?></h1>
                    <!-- Breadcrumb row -->
                    <div class="breadcrumb-row">
                        <ul class="list-inline">
                            <li><a href="{{ route('pages.home') }}">Home</a></li>
                            <li>Products</li>
                            <li><?php echo e($product->name); ?></li>
                        </ul>
                    </div>
                    <!-- Breadcrumb row END -->
                </div>
            </div>
        </div>
        <!-- inner page banner END -->
        <!-- contact area -->
        <div class="content-block">
            <!-- About Services info -->
            <div class="section-full content-inner bg-white video-section"
                 style="background-image:url(<?php echo e(url('/')); ?>/public/images/background/bg-video.png);">
                <div class="container">

                    <div class="row">
                        <div class="col-lg-6 m-b30">
                            <h2 class="text-black font-weight-600 m-b15"><?php echo e($product->name); ?></h2>
                            <?php echo $product->description; ?>

                        </div>
                        <div class="col-lg-6">
                            <div class="row">
                                <div class="col-lg-12 m-b30">
                                    <img alt="" src="<?php echo e(url('/')); ?>/public/uploads/<?php echo e($product->image); ?>">
                                </div>
                            </div>
                        </div>
                    </div>

                </div>
            </div>
        </div>
        <!-- contact area END -->
    </div>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
<script>

</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\alltech\dynamic\resources\views/pages/products_show.blade.php ENDPATH**/ ?>
