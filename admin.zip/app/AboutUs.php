<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class AboutUs extends Model
{
     protected $fillable = [
        'text',
        'text_ar'
    ];
}
