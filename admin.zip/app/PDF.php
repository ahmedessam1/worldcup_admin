<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class PDF extends Model
{
    //
}
